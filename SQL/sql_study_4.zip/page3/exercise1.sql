-- studentsテーブルからidカラムの値が7のレコードを削除してください。
DELETE FROM students

WHERE id = 7
;
-- 下記のクエリは消さないでください。
SELECT * FROM students;
