-- studentsテーブルにデータを追加してくださ
INSERT INTO students (name, course)
VALUES('Kate', 'Java')
;
-- 下記のクエリは消さないでください。
select * from students;
