--ASを使って、取得したカラム名を"チームの合計得点"としてください
SELECT SUM(goals) AS 'チームの合計得点'
FROM players
;
