-- 全商品の利益の平均を取得してください
SELECT AVG(price - cost)
FROM items
