-- 全商品の名前、値段、利益を取得してください
SELECT name, price, price - cost
FROM items
;