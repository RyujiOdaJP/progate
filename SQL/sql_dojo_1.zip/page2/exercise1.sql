-- ユーザー全体の平均年齢を取得してください
SELECT AVG(age)
FROM users
;