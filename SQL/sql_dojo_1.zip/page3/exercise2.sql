-- 全商品の名前と値段を、値段が高い順に並べてください
SELECT name, price
FROM items
ORDER BY price DESC
;