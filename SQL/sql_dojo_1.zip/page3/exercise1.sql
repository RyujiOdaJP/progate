-- 全商品の名前を重複無く取得してください
SELECT DISTINCT(name)
FROM items
;